<?php
$lLabNumber = 61;
$lTitle = "Lab 61: Cross-origin Resource Sharing (CORS) - Pre-Flight Requests";
$lQuestion = "Using the Cross-origin Resource Sharing (CORS) page to send a PUT request, what is the HTTP method of the Pre-Flight Request?";
$lChoice_1 = "HEAD";
$lChoice_2 = "PUT";
$lChoice_3 = "OPTIONS";
$lChoice_4 = "GET";
$lChoice_5 = "POST";
$lCorrectAnswer = 3;

require_once("labs/lab-template.inc");
?>
