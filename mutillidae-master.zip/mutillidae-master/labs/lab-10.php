    <?php
    $lLabNumber = 10;
    $lTitle = "Lab 10: SQL Injection - Pivoting with SQL injection";
    $lQuestion = "Using the User Info page, which of these is a credit card number stored in the Mutillidae II database?";
    $lChoice_1 = "1234567812345678";
    $lChoice_2 = "9090909090909090";
    $lChoice_3 = "3459123974521223";
    $lChoice_4 = "8139572746201465";
    $lChoice_5 = "0484629112298764";
    $lCorrectAnswer = 1;

    require_once("labs/lab-template.inc");
?>