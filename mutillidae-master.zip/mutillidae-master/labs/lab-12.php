<?php
    $lLabNumber = 12;
    $lTitle = "Lab 12: Command injection - Extracting User Accounts with Command Injection";
    $lQuestion = "Which of these accounts exists on the Mutillidae Linux server?";
    $lChoice_1 = "slack";
    $lChoice_2 = "ntp";
    $lChoice_3 = "george";
    $lChoice_4 = "fred";
    $lChoice_5 = "cmdline";
    $lCorrectAnswer = 2;

    require_once("labs/lab-template.inc");
?>