<?php
    $lLabNumber = 1;
    $lTitle = "Lab 1: Sending HTTP Requests with Netcat";
    $lQuestion = "What version of web server is running according to the Server response header?";
    $lChoice_1 = "Apache 2.x";
    $lChoice_2 = "NGinX 1.x";
    $lChoice_3 = "IIS 8.5";
    $lChoice_4 = "Apache Lite 1.x";
    $lChoice_5 = "None of the Above";
    $lCorrectAnswer = 1;

    require_once("labs/lab-template.inc");
?>