<a href="evil-tabby-cat.php" target="_blank" rel="opener">Go to the dark side</a>
